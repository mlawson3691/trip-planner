--
-- Database: `trip_planner`
--
CREATE DATABASE IF NOT EXISTS `trip_planner` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `trip_planner`;

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE `activities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `trip_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `activities`
--

INSERT INTO `activities` (`id`, `name`, `date`, `description`, `trip_id`) VALUES
(1, 'Beach time!', '2017-03-11T12:44', 'Checkout Mexicos most famous beach.', 19),
(2, 'Beach time!', '2017-03-11T12:44', 'Checkout Mexicos most famous beach.', 19),
(3, 'Beach time!', '2017-03-11T12:44', 'Checkout Mexicos most famous beach.', 19),
(4, 'Beach time!', '2017-03-11T12:44', 'Checkout Mexicos most famous beach.', 19),
(5, 'Beach time!', '2017-03-11T12:44', 'Checkout Mexicos most famous beach.', 19),
(6, 'Pool', '2015-10-06T03:44', '', 19),
(7, 'new activity', '2016-10-20T13:11', 'having fun', 20),
(8, 'Pool', '2222-02-01T01:03', '2edad', 21);

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `name`, `state`) VALUES
(1, 'Portland', 'Oregon'),
(2, 'Chicago', 'Illinois'),
(3, '', 'Alabama'),
(4, 'Pool', 'Alabama');

-- --------------------------------------------------------

--
-- Table structure for table `cities_trips`
--

CREATE TABLE `cities_trips` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `city_id` int(11) DEFAULT NULL,
  `trip_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cities_trips`
--

INSERT INTO `cities_trips` (`id`, `city_id`, `trip_id`) VALUES
(1, 2, 17),
(7, 1, 21),
(8, 4, 27),
(9, 1, 27),
(10, 1, 35),
(11, 1, 62);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `trip_id` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `rating` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `trip_id`, `description`, `rating`, `title`) VALUES
(1, 15, 'went to SE asia', '4', 'A great time with the gals'),
(2, 13, 'It was a great trip\r\n', '4', 'Good Times'),
(3, 43, 'I love this city! We had a great time!', '5', 'Good Times'),
(4, 48, 'Not so great', '2', 'Good Times');

-- --------------------------------------------------------

--
-- Table structure for table `trips`
--

CREATE TABLE `trips` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `complete` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `trips`
--

INSERT INTO `trips` (`id`, `name`, `description`, `user_id`, `complete`) VALUES
(7, 'Spring break', 'party with friends!', 2, 0),
(8, 'Spring break', 'party with friends!', 13, 0),
(9, 'Spring break', 'party with friends!', 14, 0),
(10, 'Honeymoon', 'hihi', 15, 0),
(11, 'Spring break', 'party with friends!', 16, 0),
(12, 'Honeymoon', 'So much fun', 13, 0),
(13, 'Honeymoon', 'party with friends!', 13, 0),
(14, 'Spring break', 'party with friends!', 13, 0),
(15, 'spring break', 'friends trip', 17, 0),
(16, 'Spring break', 'party with friends!', 13, 0),
(17, 'Spring break', 'party with friends!', 13, 0),
(18, 'Spring break', 'party with friends!', 13, 0),
(19, 'Spring break', 'party with friends!', 13, 0),
(20, 'Going on vacation', 'having fun in Portland', 18, 0),
(21, 'Spring break', 'party with friends!', 18, 0),
(22, 'Spring break', 'party with friends!', 13, 0),
(23, 'Spring break', 'party with friends!', 13, 0),
(24, 'Spring break', 'party with friends!', 13, 0),
(25, 'Spring break', 'party with friends!', 13, 0),
(26, 'Spring break', 'party with friends!', 13, 0),
(27, 'Spring break', 'party with friends!', 13, 0),
(28, 'Spring break', 'party with friends!', 13, 0),
(29, 'Spring break', 'party with friends!', 13, 0),
(30, 'Spring break', 'party with friends!', 13, 0),
(31, 'Spring break', 'party with friends!', 13, 0),
(32, 'Spring break', 'party with friends!', 13, 0),
(33, 'Spring break', 'party with friends!', 13, 0),
(34, 'Spring break', 'party with friends!', 13, 0),
(35, 'Spring break', 'party with friends!', 13, 0),
(36, 'Spring break', 'party with friends!', 13, 0),
(37, 'Spring break', 'Party with the girls!', 13, 0),
(38, 'Honeymoon', 'Romantic getaway for the newlyweds!', 13, 0),
(39, 'Honeymoon', 'Romantic getaway for the newlyweds!', 19, 0),
(40, 'Spring break', 'party with friends!', 20, 0),
(41, 'Spring break', 'party with friends!', 21, 0),
(42, 'Spring break', 'party with friends!', 13, 0),
(43, 'Spring break', 'party with friends!', 21, 0),
(44, 'Spring break', 'party with friends!', 13, 0),
(45, 'Spring break', 'party with friends!', 13, 0),
(46, 'Spring break', 'party with friends!', 13, 0),
(47, 'Spring break', 'party with friends!', 13, 0),
(48, 'Spring break', 'party with friends!', 13, 0),
(49, 'Spring break', 'party with friends!', 13, 0),
(50, 'Spring break', 'party with friends!', 13, 0),
(51, 'Spring break', 'party with friends!', 13, 0),
(52, 'Spring break', 'party with friends!', 13, 0),
(53, 'Spring break', 'party with friends!', 13, 0),
(54, 'Spring break', 'party with friends!', 13, 0),
(55, 'Spring break', 'party with friends!', 13, 0),
(56, 'Spring break', 'party with friends!', 13, 0),
(57, 'Spring break', 'party with friends!', 13, 0),
(58, 'Spring break', 'party with friends!', 13, 0),
(59, 'Spring break', 'party with friends!', 13, 0),
(60, 'Spring break', 'party with friends!', 13, 0),
(61, 'Spring break', 'party with friends!', 13, 0),
(62, 'Spring break', 'party with friends!', 13, 0),
(63, 'Spring break', 'party with friends!', 13, 0),
(64, 'Honeymoon', 'party with friends!', 13, 0),
(65, 'Honeymoon', 'party with friends!', 13, 0),
(66, 'Honeymoon', 'party with friends!', 13, 0),
(67, 'Honeymoon', 'party with friends!', 13, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(13, 'root', '$2y$10$s1kCvx77U7Okw21VXl5Et.24wqjNGuDATJgfF2rkJUkRETLgHT032'),
(14, 'AImen', '$2y$10$JIPVequfeiatED/qJNMoU.MwvhqjbNxf3UwHW92/MpeG1waq1FKjy'),
(15, 'aimen biggy', '$2y$10$vT9gw/bcbuHB8Ox3tPV9uedKrnpRaD/lqv3nalCFIyjdFySoRSg8O'),
(16, 'dmcfkaldsmf', '$2y$10$fXw66kLPi/LjJBws9oXrCuKH9Tgx0vaIRcokoOfdYWz8MXq91An26'),
(17, 'ayana', 'powell'),
(18, 'mark', '$2y$10$Vdts0XIvFMFvihDdof1.Cekm0nTZjfMii.IGv/gLMFJCBOhd2IDwm'),
(19, 'Ayana Powell', '$2y$10$HoukPIpo2GOZfEKHOostxe3I5Ll/UPGxMTnswYqjtR2BPxmLiWZJ.'),
(20, 'apples', '$2y$10$RorAIp53gSKU7JJM0lz19eWDmjvxujyHcrf4szA/ab13v15ioRJl6'),
(21, 'epicodus', '$2y$10$VUPyPqMBFS.kW39U5QqtE.QT0zrByvvpJY/5fudZHm9YgnESixaNy');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `cities_trips`
--
ALTER TABLE `cities_trips`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `trips`
--
ALTER TABLE `trips`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activities`
--
ALTER TABLE `activities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `cities_trips`
--
ALTER TABLE `cities_trips`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `trips`
--
ALTER TABLE `trips`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
