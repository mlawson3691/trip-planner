--
-- Database: `trip_planner`
--
CREATE DATABASE IF NOT EXISTS `trip_planner` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `trip_planner`;

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE `activities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `trip_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `activities`
--

INSERT INTO `activities` (`id`, `name`, `date`, `description`, `trip_id`) VALUES
(15, 'Rose Garden', '2016-01-01T13:00', 'Explore Portlands Rose Garden', 8),
(16, 'Hiking at Multonomah Falls', '2016-01-01T12:00', 'Hike to see Portlands views!', 8),
(17, 'Segway Tour!', '2016-01-01T12:00', 'Tour the Portland Bridges on a Segway', 8),
(18, 'Boating at White Rock Lake', '2016-03-14T15:00', 'Going canoeing ', 9),
(19, 'Dallas World Aquarium', '2016-01-15T13:00', '', 9),
(20, 'Dallas Zoo', '2016-01-15T16:00', '', 9),
(21, 'Dallas World Aquarium', '2016-01-01T12:00', '', 10),
(22, 'Dallas Zoo', '2016-01-01T12:00', '', 10),
(23, 'Reunion Tower', '2016-01-01T12:00', '', 10),
(24, 'Statue of Liberty!!', '2016-01-07T08:00', 'Going to see the statue of liberty!', 11),
(25, 'Ellis Island', '2016-01-07T15:00', '', 11),
(26, 'Yankee Stadium!!!', '2016-01-07T17:00', 'Checking out the home of the Yankees!', 11),
(27, 'French Quarter', '2016-01-22T13:00', '', 12),
(28, 'Bourbon Street', '2016-01-23T14:00', '', 12),
(29, 'The Cabildo', '2016-01-22T17:00', '', 12),
(30, 'Audobon Park ', '2016-01-23T13:00', '', 12),
(31, 'Diamond Head', '2016-01-01T19:00', 'Volcanic Landmark', 13),
(32, 'Snorkeling at Hanauma Bay', '2016-01-01T15:00', '', 13),
(33, 'Bishop Museum ', '2016-01-02T14:00', '', 13),
(34, 'Hiking at Koko Falls', '2016-01-01T12:00', '', 13),
(35, 'World Center for Birds of Prey', '2016-01-01T15:00', '', 14),
(36, 'Idaho Botanical Garden', '2016-01-07T08:00', '', 14),
(37, 'Fishing at Lucky Peak Lake', '2016-01-01T16:00', '', 14),
(38, 'The Egyptian Center', '2016-01-08T17:00', '', 14),
(39, 'Dallas Cowboys Game', '2016-01-01T12:00', '', 15),
(40, 'Dinner and Drinks ar El Guacho', '2016-01-01T12:00', '', 15),
(41, 'Shopping at Dallas Mall', '2016-01-01T12:00', '', 15),
(42, 'Dancing in the Elephant Room', '2016-01-01T12:00', '', 15),
(47, 'Hiking at Blue Ridge State Park', '2016-01-01T12:00', '', 17),
(48, 'Shopping for groceries at Healthy Heart Co-op', '2016-01-01T12:00', '', 17),
(49, 'Swimming at Indigo lake', '2016-01-01T12:00', '', 17),
(50, 'Horseback Riding at Lazy Double L Ranch', '2016-01-01T12:00', '', 17),
(51, 'Camping at Blue Ridge State Park', '2016-01-01T12:00', '', 18),
(52, 'Horseback Riding at Lazy Double L Ranch', '2016-01-01T12:00', '', 18),
(53, 'Bass fishing at Anderson River Reservoir', '2016-01-01T12:00', '', 19),
(54, 'Beers at Hanks', '2016-01-01T12:00', '', 19),
(55, 'Camping at Boise Valley State Park', '2016-01-01T12:00', '', 19),
(56, 'Bass fishing at Lake Lowell', '2016-01-01T12:00', '', 19),
(57, 'Coffee at Cavadora Cafe', '2016-01-01T12:00', '', 21),
(58, 'Hanging out at Rockview Park', '2016-01-01T12:00', '', 21),
(59, 'Movie at the Egyptian Theater', '2016-01-01T12:00', '', 21),
(60, 'Drinks and Dinner at the Alligator', '2016-01-01T12:00', '', 21),
(61, 'Tom McCall Waterfront Park', '2016-01-01T12:00', '', 21),
(62, 'Pizza and Drinks at Sizzle Pie', '2016-01-01T12:00', '', 21),
(63, 'Karaoke at Chopsticks', '2016-01-01T12:00', '', 21),
(64, 'Zion Dispensary', '2016-01-01T12:00', '', 21),
(65, 'Mt. Tabor Park', '2016-01-01T12:00', '', 21),
(66, 'Times Square', '2016-01-01T12:00', '', 22),
(67, 'Cupcakes at Magnolia Bakery', '2016-01-01T12:00', '', 22),
(68, 'Shoe shopping at Manolo Blahnik', '2016-01-01T12:00', '', 22),
(69, 'Cosmos at Stiletto Lounge', '2016-01-01T12:00', '', 22),
(70, 'Shopping at C A T S O H O', '2016-01-01T12:00', '', 23),
(71, 'Drinks at Russian Tea House', '2016-01-01T12:00', '', 23),
(72, 'Dinner at yoshi', '2016-01-01T12:00', '', 23),
(73, 'Pikes Place Market', '2016-01-01T12:00', '', 24),
(74, 'Fish Haus', '2016-01-01T12:00', '', 24),
(75, 'Gas Works Park', '2016-01-01T12:00', '', 24),
(76, 'Drinks on Capitol Hill (various bars)', '2016-01-01T12:00', '', 24),
(77, 'Manicures at Dime Salon', '2016-01-01T12:00', '', 24),
(78, 'Brunch at Cafe Dory', '2016-01-01T12:00', '', 24),
(79, 'Snorkeling at Shark Cove', '2016-01-01T12:00', '', 25),
(80, 'Dinner at Dukes', '2016-01-01T12:00', '', 25),
(81, 'Waikiki Beach', '2016-01-01T12:00', '', 25),
(82, 'Kona Coffee Tour', '2016-01-01T12:00', '', 25),
(83, 'Kiluea Lava Hike', '2016-01-01T12:00', '', 25);

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `name`, `state`) VALUES
(7, 'Portland', 'Oregon'),
(8, 'Dallas', 'Texas'),
(9, 'New York', 'New York'),
(10, 'New Orleans', 'Louisiana'),
(11, 'Honolulu', 'Hawaii'),
(12, 'Boise ', 'Idaho'),
(13, 'Seattle', 'Washington'),
(14, 'Kona', 'Hawaii'),
(15, 'Hilo', 'Hawaii');

-- --------------------------------------------------------

--
-- Table structure for table `cities_trips`
--

CREATE TABLE `cities_trips` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `city_id` int(11) DEFAULT NULL,
  `trip_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cities_trips`
--

INSERT INTO `cities_trips` (`id`, `city_id`, `trip_id`) VALUES
(12, 7, 8),
(13, 8, 9),
(14, 8, 10),
(15, 9, 11),
(16, 10, 12),
(17, 11, 13),
(19, 12, 14),
(20, 8, 15),
(22, 12, 17),
(23, 12, 18),
(24, 12, 19),
(25, 9, 23),
(26, 13, 24),
(27, 11, 25),
(28, 14, 25),
(29, 15, 25);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `trip_id` int(11) DEFAULT NULL,
  `rating` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `trip_id`, `rating`, `title`, `description`) VALUES
(4, 8, '5', 'Best Grad Trip EVER!!!', 'Thank you Portland for a wonderful and real experience! Ive never been to Oregon before but as a foodie I have had been wanting to go and had and still have so many places booked marked! I honestly didnt know what to expect but to my delight this is a hipster, funky, partying town where everyone is polite and no one looks the same. I appreciated the individuality.The Food scene is like no other! I think I gained ten pounds! I was amazed with the options; food carts, fancy, dives, a bit of everything anyone would want or need! \r\n\r\nWe ventured out on a Monday and Tuesday night... Why were the bars filled to the brim? Does the town sleep?\r\n\r\nBetween the use of Lyft and walking we were able to get to the majority of the places we wanted to visit. We did notice a large homeless population and camps which is not allowed in California (where we are from), I soon realized the mayor has allowed for the homeless to sleep in the streets. Interesting solution to the problem but it was good to see these folks out of luck werent not being run off. \r\n\r\nMy time was way too short, which means Ill be returning! Thank you Portland, I greatly appreciate the hospitality! Cheers!'),
(5, 10, '3', 'Overall great trip to Dallas', 'One of my favorite citys to visit...THE BIG D has plenty to offer everyone. No matter your interest. Tons of amazing eateries, aquariums, museums, shopping, hot spots for bars, adult entertainment, day spas, the "arts", history buffs and much much more. Pretty easy to get to anything in town within 30 min or so as long as youve got wheels however, traffic can be a doozie at sporadic times so travel with plenty of time to spare. \r\n\r\nTake in Dallas beautiful skyscrapers, city night lights and that infamous BG sign where you can stand in the middle to create a cool "I".'),
(6, 11, '4', 'Everyone should visit NYC', 'Traffic, honking horns, wall to wall tourists, crowded subway trains - there are a lot of things that you could say negatively about NYC. But....it is a unique, one-of-a-kind city within the USA and known throughout the world as The Big Apple. \r\n\r\nNYC has so much to offer both locals and tourists. It has so many facets to it - so many interesting sites, cool boroughs, good restaurants. Public transportation is easy to maneuver and is very convenient. The views of the bay, with the Statue of Liberty, and the beautiful skyline are spectacular. And the best bagels on earth are here!\r\n\r\nYes, NYC is a treasure to behold. Everyone needs to visit this place at least once.'),
(7, 12, '5', 'City Of New Orleans', 'My introduction to this charming city goes back to undergrad when I volunteered with Habitat For Humanity after Hurricane Katrina. Instead of going home for Fall Back, about 20 of us piled into two vans and drove 11hrs to NOLA. For our 1st mission, we stayed at Camp Hope, a school-turned-camp site in the Jefferson Parish, right across from the navy shipyard. The 2nd mission, we stayed in the heart of the Ninth Ward.\r\n\r\nNot only did we aid in disaster relief, but at night, we got a chance to recharge and party. We got the best of both worlds. We walked the riverfront, ate at Oceania, experience the Cathedral Brasilica of St. Louis King of France and of course, stopped at Café Du Monde. \r\n\r\nNOLA gave me much perspective and provided me some the best memories of my life. Thats why I love it so much. The people are welcoming, the culture is beautiful, AND THE FOOD?!! Listen. Theres not enough words...\r\n\r\nI cant wait to go back; its been TOO long.'),
(8, 13, '5', 'Take me back...', 'Took my first trip to HAWAII this month and truly saw paradise! Being raised on Miami Beach, I have traveled world-wide, seen many beautiful places- but seeing HAWAII is at the top of my list and worth every penny spent to do so!\r\n\r\nI could do this trip "over and over again" and still be happy in doing so! With the dollar being down, now is the time to visit our state of Hawaii and its lovely people and experience true "Aloha Spirit".\r\n\r\nPS: Dont forget to toss your final lei into the water and make a wish to return! I sure did and I hope it works! '),
(9, 14, '3', 'Relaxing trip', 'I traveled to Boise, Idaho for a week in the fall of 2009 and really enjoyed my visit. For such a small city, Boise has a lot of interesting things to do, attractions to see and a really relaxed and inviting vibe. Downtown Boise, near the Idaho State Capitol, is the best part of the city for travelers and tourists. Many of the Boise restaurants and bars in downtown, particularly along Eighth Street, are exceptional, and microbrew enthusiasts will find many distinctive Pacific Northwest beers on tap throughout the city. The shopping in downtown Boise, though, could be better. There are many other things to do and other attractions to see in Boise besides eating and drinking downtown, of course. The Basque Museum and Cultural Center, which details the history of one of Idahos most important ethnic groups, is one of the best small museums Ive ever been to. Boise is also a fantastic place for birding. Both the Idaho Center for Birds of Prey and the Boise River greenbelt are great places to see many native and introduced bird species.'),
(10, 15, '4', 'Great Experience', 'Spent the weekend in Dallas visiting a friend. We went to see the Cowboys (my first time), and had a lot of fun! Never been to a game that exciting before, the only thing I didn’t like was the condition of the restrooms in the stadium (replenish your toilet paper, please!).\r\n\r\nAfter the game we stopped by El Gaucho for some tasty margaritas and food. I got the spicy pomegranate margarita, which was DELICIOUS!\r\n\r\nWe made sure to spend some time at the mall shopping for cute dresses the next day, as we just had to go out dancing at least one night. We ended up going to the Elephant Room, which I thought was a little too expensive though I still had a great time.\r\n\r\nReally liked the Texas charm of Dallas, though I still don’t feel like I know the city well. Guess I’ll just have to come back!\r\n'),
(11, 16, '4', 'Pretty good bass', 'Me and my buddy Joe went on a bass fishin adventure in Boise to celebrate our divorces. We took Joe’s RV and got straight to fishin at Anderson River Reservoir, where we caught a fair amount of bass, mostly on the smaller side. After some cold brews at Hanks we camped out for the night. Lake Lowell was a bass dream- Joe and I both got 20 pounders, God bless America!!\r\n\r\nWe will definitely try to come back to Lake Lowell for the bass next year, and maybe see a little more of the country out here.'),
(12, 18, '5', 'Beautiful Romantic Camping', 'Me and bae had a lovely time getting away from the city out in the nature of Idaho. We stayed at an adorable cozy cottage in Blue Ridge State Park, cooked artisanal hotdogs, and rode horses in the hills.'),
(13, 19, '4', 'Pretty good bass', 'Me and my buddy Joe went on a bass fishin adventure in Boise to celebrate our divorces. We took Joe’s RV and got straight to fishin at Anderson River Reservoir, where we caught a fair amount of bass, mostly on the smaller side. After some cold brews at Hanks we camped out for the night. Lake Lowell was a bass dream- Joe and I both got 20 pounders, God bless America!!\r\n\r\nWe will definitely try to come back to Lake Lowell for the bass next year, and maybe see a little more of the country out here.'),
(14, 21, '5', 'PNW Experience', 'My brother and I decided to take a spontaneous road trip through the PNW. Starting in northwest WA, we started driving down I-5 to Seattle. We stayed with a friend of mine in Ballard for the next two nights, which was  fun, hip, up & coming neighborhood. We spent the afternoon drinking delicious coffee from Cavadora Cafe and hanging out at the park before heading into the city proper to see a movie at the Egyptian Theater on Capitol Hill. The Egyptian is a must for anyone with a passing interest in film, or really anyone would enjoy watching classic, foreign, or indie movies in a funky old theater with great vibes. Afterward, we all got beers and some nachos at the Alligator. Plenty of micros to choose from & the nachos were tasty and HUGE.\r\n\r\nThe next day we drove to Portland, where we were staying with another friend. We took the MAX light rail downtown and walked down the waterfront before going to happy hour at Sizzle Pie- so hip, so cheap! That night we went to karaoke at Chopsticks. I had a good time even though the bar was a little too crowded and raucous for my taste. The next day we hit up Zion Dispensary for some legal joints and took a long walk around Mt. Tabor Park.\r\n\r\nOverall, this trip was very chill.'),
(15, 22, '5', 'Glamorous Dream Living the City Life', 'Me and the girls LOVE Sex and the City, so we decided to celebrate my 40th by taking a girls’ trip to the Big Apple. It was all so glamorous, I can’t believe I actually splurged on my first pair of Manolos (Carrie would be so proud).\r\n\r\nWe stayed at the Josie Hotel in Midtown. The cosmos in the hotel’s restaurant and bar, the Josie Fina, were not as good as the ones we had at Stiletto, but the employees were\r\nall so friendly and accommodating, treating us like princesses the whole time. Would definitely recommend.'),
(16, 23, '4', 'Quick business trip in NYC', 'I was in town from D.C. on business for a night. I had little spare time to shop at C A T boutique, where I picked up a gorgeous new bag and some jewelry. I always love shopping here when I have the chance! Next, I took my client to the Russian Tea House for some vodka and caviar, where everything we tasted was excellent- this place is a classic for a reason.\r\n\r\nWe had an upscale sushi dinner that night at yoshi, a trendy new spot I didnt think entirely lived up to the hype. I was staying at the Chandler Hotel as I always do, as I have never had anything short of a top quality experience.'),
(17, 24, '5', 'Fun weekend!', 'I spent a weekend in Seattle for my sisters Bachelorette party. Overall, I really enjoyed the hip modern vibe of the city. When I arrived Friday afternoon, my sister showed me around some of the citys more well known attractions- we spent an hour wandering around Pikes Place, enjoyed a delicious seafood lunch at Fish Haus, then walked off our meal at Gas Works park on the water. \r\n\r\nThat night, we went out bar hopping & dancing around the Capitol Hill area. While I cant remember exactly where we went, we had a lovely, just-wild-enough kind of night ;)\r\n\r\nOn Saturday we went to recuperate over brunch at Dorys cafe- I had the eggs benedict with a bloody mary, and would highly recommend both. We followed up brunch with manicures before I flew home that evening. I had a great time, and cant wait to go back for the wedding in two weeks!'),
(18, 25, '5', 'Lovely beach trip', 'My partner and I took a week off work for a romantic getaway in Hawaii. We split our time between Oahu and the Big Island. We had a great time in the sun, sipping mai tais and exploring the islands.');

-- --------------------------------------------------------

--
-- Table structure for table `trips`
--

CREATE TABLE `trips` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `complete` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `trips`
--

INSERT INTO `trips` (`id`, `name`, `description`, `user_id`, `complete`) VALUES
(8, 'My Grad Trip', 'For graduating with my Masters!', 6, 1),
(9, 'Short and sweet family trip', 'Spending time with the extended fam!', 6, 1),
(10, 'Summer Getaway', '', 6, 1),
(11, 'Exploring the Big Apple', 'Going to New York', 7, 1),
(12, 'New Orleans here I come!!!!', 'Visiting New Orleans', 7, 1),
(13, 'Roadtrip', '', 8, 1),
(14, 'Relaxing in Boise', 'My annual trip to Boise!', 8, 1),
(15, 'Dancing in Dallas', '', 8, 1),
(17, 'BaeCation', 'me & bae went camping <3', 6, 1),
(18, 'BaeCation', 'camping with bae <3', 6, 1),
(19, 'Bass Fishing with Joe', '', 9, 1),
(21, 'Road Trip', 'Road trip with my brother', 10, 1),
(22, 'SEX AND THE CITY TRIP', '', 11, 1),
(23, 'Business in NYC', '', 12, 1),
(24, 'Bachelorette Weekend', '', 12, 1),
(25, 'Romantic Getaway', '', 12, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `bio` text,
  `location` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `name`, `bio`, `location`) VALUES
(6, 'katy7896', '$2y$10$mKuc3d1dYC5HY9JEv8oLZ.S1NsX3h1Awa06iBRvZJz1hM86KNaawi', 'Katy Olsen', 'Hi, my name is Katy, and I love to travel. Welcome to my page...lets go SPLORE!', 'Dallas'),
(7, 'nomad2090', '$2y$10$wouAr0iWimsH3cko9fXsGufs32JG8rEo8iDhI9wNUqjo3qU/DpqKa', 'Matt Nelson', 'Hey there! My name is Matt and I consider myself a nomad. Join me in my travels', 'Miami, Florida'),
(8, 'traveladdict', '$2y$10$B7a2LapE2cZJgQZ9gxijmODHbcnK9BLMuzVYX/NVYniyPgUUP5biu', 'Nathan Hall', 'Travel addict. Coffee lover. Dont stop till you die', 'Washington DC'),
(9, 'Bud', '$2y$10$LvLFtyTVsuyBfOPp2JOu/.ZlvGt1fK0yOlcnUd.y9lCFLKd5hJjHS', 'Bud Budson', 'Huntin, Fishin, Brews with my boys.', 'Steer Valley, Nevada'),
(10, 'the_jeff_man420', '$2y$10$gGULqpkbqfIEPLaUqW.wBuznyzNJsrDy7ziCfjVexGuGszKpnLdhK', 'Jeff Johnson', 'Peace and Love, video games, 420.', 'Bellingham, WA'),
(11, 'missus_rochester', '$2y$10$80tLZnSpoACnOe6bWrbF1uWUgdjx7iIakutkTfx/GN5zmEs5XApP.', 'Dana Smith', 'Mom of 2, sugar lover, SatC fan #1, a true Carrie', 'Brookline, Massachusettes'),
(12, 'molly', '$2y$10$xbX73Aa5ZPJhY3CGHxS.U.MbZl/5LFKAmsKZkhVUbXZ2Tpqq3pZfi', 'Molly Kay ', 'Young professional woman about town', 'Portland, OR');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `cities_trips`
--
ALTER TABLE `cities_trips`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `trips`
--
ALTER TABLE `trips`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activities`
--
ALTER TABLE `activities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;
--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `cities_trips`
--
ALTER TABLE `cities_trips`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `trips`
--
ALTER TABLE `trips`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
